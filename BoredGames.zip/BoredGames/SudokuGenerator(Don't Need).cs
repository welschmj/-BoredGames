private void sudokuInitializer()
{
	int sudoku [9][9];
	long num_tries = 0;
	long num_things = 0;
	
	
}