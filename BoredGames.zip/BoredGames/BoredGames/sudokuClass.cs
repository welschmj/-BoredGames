﻿using System;

public class Sudoku
{
	public Sudoku()
	{
	
    
    
    }

}
